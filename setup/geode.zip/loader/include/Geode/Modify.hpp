#pragma once

#include "modify/Modify.hpp"

#include <Geode/GeneratedModify.hpp>

using namespace geode::modifier;